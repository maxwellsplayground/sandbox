function testPOST(){
    console.log()
    var request = new XMLHttpRequest();
    request.open('POST','/',true);
    request.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8');
    request.send();  

}