from django import forms
from .models import *

class UserInfo(forms.Form):
    first_name = forms.CharField(max_length=20)
    last_name = forms.CharField(max_length=30)

class CoffeeShopForm(forms.Form):
    name = forms.CharField(max_length=20)

class BarristaInfo(forms.Form):
    first_name = forms.CharField(max_length=20)
    last_name = forms.CharField(max_length=30)

class CoffeeOptionForm(forms.Form):
    brand_name = forms.CharField(max_length=25)
    cafienated = forms.BooleanField()

class UploadForm(forms.ModelForm):
    
    class Meta:
        model = CSVFile
        fields = ('new_file',)
   

   