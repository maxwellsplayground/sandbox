from django.shortcuts import render,redirect, HttpResponse
from . import forms
from .forms import CoffeeShopForm,CoffeeOptionForm, UploadForm
from .tables import *
from tkinter import Tk
from tkinter.filedialog import askdirectory
from .models import CoffeeShop, CSVFile
import csv

# Create your views here.
def index(request):
    print("hello")
    coffee_shop_table = CoffeeShopTable(CoffeeShop.objects.all())
    coffee_shop_form = CoffeeShopForm()
    UploadFile = UploadForm(request.POST, request.FILES)

    coffee_form = CoffeeOptionForm()

    if request.method == 'GET':
        print('get has begot')
        return render(request,'index.html',{'coffee_shop_table':coffee_shop_table,'coffee_shop_form':coffee_shop_form,'uploadFile':UploadForm()})
    
    if request.method =='POST':
        data = request.POST.copy()
        
        print('post schmost')
        print(data)
   
        return render(request,'index.html',{'coffee_shop_table':coffee_shop_table,'coffee_form':coffee_form,'uploadFile':UploadFile})

def shopInfo(request, id):
    print(request,id)
    coffeeshop = CoffeeShop(id=id)
    print(coffeeshop.name)
    print(coffeeshop.id)
    print(coffeeshop)
    return render(request,'shops.html',{'shop':coffeeshop})